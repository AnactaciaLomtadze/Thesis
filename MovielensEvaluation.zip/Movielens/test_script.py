"""
Example script showing how to use the EnhancedEvaluationMetrics class
to evaluate forgetting mechanisms in recommendation systems.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm

# Import your classes
from knowledge_graph import MovieLensKnowledgeGraph
from forgetting_mechanism import ForgettingMechanism
from enhanced_evaluation_metrics import EnhancedEvaluationMetrics

# Output directory
OUTPUT_DIR = './enhanced_results'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Add this function to test_script.py
def calculate_entropy(preferences):
    """
    Calculate entropy while properly handling zeros.
    
    Args:
        preferences: Array of preference values
        
    Returns:
        Entropy value
    """
    # Ensure we don't have negative values
    prefs = np.maximum(preferences, 0)
    
    # Normalize to sum to 1 if not already
    if np.sum(prefs) > 0:
        prefs = prefs / np.sum(prefs)
    
    # Calculate entropy only for non-zero values
    entropy = 0
    for p in prefs:
        if p > 0:
            entropy -= p * np.log2(p)
    
    return entropy

def main():
    # Initialize the knowledge graph
    print("Loading MovieLens data...")
    kg = MovieLensKnowledgeGraph(data_path='./ml-100k')
    kg.load_data()
    kg.build_knowledge_graph()
    
    # Initialize forgetting mechanism
    print("Initializing forgetting mechanism...")
    fm = ForgettingMechanism(kg)
    
    # Initialize evaluation metrics
    print("Setting up evaluation metrics...")
    evaluator = EnhancedEvaluationMetrics(kg, fm, output_dir=OUTPUT_DIR)
    
    # Create temporal train-test split
    print("Creating train-test split...")
    test_data = kg.create_temporal_train_test_split(test_days=30)
    
    # Select a sample of users for evaluation (for efficiency)
    all_users = list(test_data.keys())
    np.random.seed(42)  # For reproducibility
    if len(all_users) > 50:
        test_users = np.random.choice(all_users, 50, replace=False)
    else:
        test_users = all_users
    
    print(f"Evaluating {len(test_users)} users...")
    
    # Define forgetting mechanisms to evaluate
    # Each tuple contains: (forgetting_function, recommendation_function, mechanism_type)
    forgetting_mechanisms = {
        'Time-Based': (
            lambda user_id: fm.implement_time_based_decay(user_id, decay_parameter=0.1),
            lambda user_id: kg.get_hybrid_recommendations(user_id),
            'Decay-Based'
        ),
        'Ebbinghaus': (
            lambda user_id: fm.implement_ebbinghaus_forgetting_curve(user_id),
            lambda user_id: kg.get_hybrid_recommendations(user_id),
            'Decay-Based'
        ),
        'Power-Law': (
            lambda user_id: fm.implement_power_law_decay(user_id),
            lambda user_id: kg.get_hybrid_recommendations(user_id),
            'Decay-Based'
        ),
        'Usage-Based': (
            lambda user_id: fm.implement_usage_based_decay(user_id),
            lambda user_id: kg.get_hybrid_recommendations(user_id),
            'Usage-Based'
        ),
        'Hybrid-Decay': (
            lambda user_id: fm.create_hybrid_decay_function(user_id),
            lambda user_id: kg.get_hybrid_recommendations(user_id),
            'Hybrid'
        ),
        'Personalized': (
            lambda user_id: fm.create_hybrid_decay_function(
                user_id,
                **fm.personalize_forgetting_parameters(user_id)
            ),
            lambda user_id: kg.get_hybrid_recommendations(user_id),
            'Personalized'
        )
    }
    
    # Define baseline recommender (without forgetting)
    baseline_recommender = lambda user_id: kg.get_hybrid_recommendations(user_id)
    
    # Compare forgetting mechanisms
    print("Comparing forgetting mechanisms...")
    results_df = evaluator.compare_forgetting_mechanisms(
        test_users,
        test_data,
        baseline_recommender,
        forgetting_mechanisms,
        k_values=[5, 10, 20]
    )
    
    # Save results to CSV
    results_df.to_csv(os.path.join(OUTPUT_DIR, 'forgetting_mechanisms_results.csv'), index=False)
    
    # Create comprehensive summary
    print("Creating comprehensive summary...")
    summary = evaluator.create_comprehensive_summary(
        results_df,
        output_prefix="forgetting_summary",
        k=10
    )
    
    # Analyze tradeoffs between accuracy and beyond-accuracy metrics
    print("Analyzing tradeoffs...")
    accuracy_metrics = [f'hit_rate@10', f'precision@10', f'ndcg@10', 'mrr']
    beyond_accuracy_metrics = ['diversity', 'novelty', 'serendipity']
    
    tradeoffs_df = evaluator.analyze_tradeoffs(
        results_df,
        accuracy_metrics,
        beyond_accuracy_metrics,
        output_prefix="tradeoff_analysis"
    )
    
    # Evaluate temporal impact (using a smaller sample for efficiency)
    print("Evaluating temporal impact...")
    time_sample_users = np.random.choice(test_users, min(10, len(test_users)), replace=False)
    
    temporal_results = evaluator.evaluate_temporal_impact(
        time_sample_users,
        test_data,
        forgetting_mechanisms,
        time_points=6,
        max_days=180,
        k=10
    )
    
    # Save temporal results
    temporal_results.to_csv(os.path.join(OUTPUT_DIR, 'temporal_results.csv'), index=False)
    
    # Analyze temporal dynamics
    temporal_analysis = evaluator.analyze_temporal_dynamics(
        temporal_results,
        output_prefix="temporal_analysis"
    )
    
    # Define user segments
    print("Evaluating user segments...")
    # Create segments based on user activity and diversity of tastes
    user_segments = {}
    
    # Group by activity level
    user_ratings_count = {}
    for user_id in test_users:
        user_ratings = kg.ratings_df[kg.ratings_df['user_id'] == user_id]
        user_ratings_count[user_id] = len(user_ratings)
    
    median_count = np.median(list(user_ratings_count.values()))
    
    user_segments['High Activity'] = [uid for uid, count in user_ratings_count.items() 
                                     if count > median_count]
    user_segments['Low Activity'] = [uid for uid, count in user_ratings_count.items() 
                                    if count <= median_count]
    
    # Group by taste diversity (genre entropy)
    user_diversity = {}
    for user_id in test_users:
        if user_id in kg.user_profiles:
            genre_prefs = kg.user_profiles[user_id]['genre_preferences']
            # Calculate entropy as a measure of diversity
            entropy = calculate_entropy(genre_prefs)
            user_diversity[user_id] = entropy
    
    if user_diversity:
        median_diversity = np.median(list(user_diversity.values()))
        
        user_segments['Diverse Taste'] = [uid for uid, div in user_diversity.items() 
                                         if div > median_diversity]
        user_segments['Focused Taste'] = [uid for uid, div in user_diversity.items() 
                                         if div <= median_diversity]
    
    # Evaluate segments
    segment_results = evaluator.evaluate_user_segments(results_df, user_segments, k=10)
    
    # Save segment results
    segment_results.to_csv(os.path.join(OUTPUT_DIR, 'segment_results.csv'), index=False)
    
    # Visualize segment results
    evaluator.visualize_user_segments(segment_results, output_prefix="segment_analysis")
    
    # Generate executive summary
    print("Generating executive summary...")
    all_results = {
        'mechanisms': results_df,
        'tradeoffs': tradeoffs_df,
        'temporal': temporal_analysis,
        'segments': segment_results
    }
    
    executive_summary = evaluator.generate_executive_summary(
        all_results,
        output_prefix="forgetting_executive_summary"
    )
    
    print(f"Evaluation complete. Results saved to {OUTPUT_DIR}")
    print("\nTop recommendations from executive summary:")
    for rec in executive_summary.get('recommendations', []):
        print(f"- {rec}")


if __name__ == "__main__":
    main()